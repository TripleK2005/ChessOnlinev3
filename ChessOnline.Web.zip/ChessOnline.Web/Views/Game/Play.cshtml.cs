using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChessOnline.Web.Views.Game
{
    public class PlayModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
