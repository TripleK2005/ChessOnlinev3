using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChessOnline.Web.Views.Account
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
