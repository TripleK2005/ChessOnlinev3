using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChessOnline.Web.Views.Account
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
