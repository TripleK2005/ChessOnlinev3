using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChessOnline.Web.Views.Shared
{
    public class _AuthLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
